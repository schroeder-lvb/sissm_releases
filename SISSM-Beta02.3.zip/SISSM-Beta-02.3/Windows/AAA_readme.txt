
Both 32- and 64-bit versions are included.
_restricted variants are for GSPs (game service providers).  These applications are missing reboot script shell execution feature.

DEBUG versions are not released due to false trigger by numerous antivirus products.  If you need the DEBUG version, please 1) compile it from the source, or 2) contact me directly.

