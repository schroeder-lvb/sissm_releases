SISSM Beta Release 

https://github.com/schroeder-lvb/sissm/
See sissm_quickstart.txt for first-time installers.

Note: Only "soft Reboot" will be used for the "restricted" binary, as scripting option is disabled.

For Windows, _dbg compiled binary is also included.  Some users have reported getting optimized/release binary
on WinServers.  The _dbg version, however, may trigger a false positive depending on your antivirus product
which flags development executables as suspicious.


