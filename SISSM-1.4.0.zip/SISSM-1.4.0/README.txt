SISSM Release 

https://github.com/schroeder-lvb/sissm/
See sissm_quickstart.txt for first-time installers.

Note: Only "soft Reboot" will be used for the "restricted" binary, as scripting option is disabled.

For Windows, _dbg compiled binary is NO LONGER supported.  Some users have reported getting optimized/release binary
on WinServers.  The _dbg version, however, triggers false positive on antivirus products.


